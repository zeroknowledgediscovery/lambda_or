from .lambda_or import lambda_or, pq_from_two_gates, LambdaORResult
__all__ = ["lambda_or", "pq_from_two_gates", "LambdaORResult"]
__version__ = "0.1.0"

